from django.apps import AppConfig


class ProfieConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'profie'

    def ready(self):
        import profie.signals