# profiles/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import UserForm, ProfileForm, SkillForm
from .models import Skill

@login_required
def profile_view(request):
    user_form = UserForm(instance=request.user)
    profile_form = ProfileForm(instance=request.user.profile)
    skill_form = SkillForm()
    skills = Skill.objects.filter(profile=request.user.profile)

    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            return redirect('profile')

        skill_form = SkillForm(request.POST)
        if skill_form.is_valid():
            skill = skill_form.save(commit=False)
            skill.profile = request.user.profile
            skill.save()
            return redirect('profile')

    return render(request, 'profiles/profile.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'skill_form': skill_form,
        'skills': skills
    })

@login_required
def delete_skill(request, skill_id):
    skill = Skill.objects.get(id=skill_id)
    if skill.profile.user == request.user:
        skill.delete()
    return redirect('profile')
