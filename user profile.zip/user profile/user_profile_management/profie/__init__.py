# profiles/__init__.py
default_app_config = 'profiles.apps.ProfilesConfig'
